<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user): ?>
    <div class="flex flex-col items-start leading-tight">
        <span class="text-sm font-semibold text-gray-900 dark:text-gray-100">
            <?php echo e($user->name); ?>

        </span>

        <span class="text-xs text-gray-500 dark:text-gray-400">
            <?php echo e($role ?? 'User'); ?>

        </span>
    </div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH G:\MyProjects\BookingSystem\salon-sass\resources\views/filament/components/user-menu-meta.blade.php ENDPATH**/ ?>