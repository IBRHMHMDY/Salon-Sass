<?php

namespace App\Filament\Admin\Resources\Salons\Pages;

use App\Filament\Admin\Resources\Salons\SalonResource;
use App\Filament\Shared\Pages\EditRecordRedirectToIndex;
use Filament\Actions\DeleteAction;

class EditSalon extends EditRecordRedirectToIndex
{
    protected static string $resource = SalonResource::class;

    protected function getHeaderActions(): array
    {
        return [
            DeleteAction::make(),
        ];
    }
}
